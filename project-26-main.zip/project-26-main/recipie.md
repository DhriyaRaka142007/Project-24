# How to make recipe

1. Add 1/2 cup moong dal to a heavy bottom pan or pressure cooker.
2. Dry roast it on a medium flame stirring often till the dal turns light golden.
3. Next add 1/2 cup rice to the same pan. Pour some water and rinse both of them at least 2 to 3 times. Be careful as the pot is hot. Drain water completely.
4. Pour 2*3/4 cups of water. Cover the cooker and pressure cook for 2 to 3 whistles. If cooking pot, pour more water.
5. You can also put rice and dal in a bowl and pour water. Place the bowl in a pressure cooker. Pressure cook for 3 whistles.
6. To make jaggery syrup, transfer 1/4 cup water and 1/2 cup grated jaggery to a small pan. You can also skip this step and add clean jaggery to the mashed rice.
7. On a low flame stir and melt it. Boil until slightly thicj and sticky. Do not over cook as this turns too thick after cooling. Set this aside.
8. When the pressure releases, open the cooker and mash the rice and dal lightly. Both should be soft cooked.
9. Next filter jaggery syrup directly to the cooked rice and dal. Add 1/4 to 1/2 teaspoon elaichi powder.
10. Mix and cook on a medium flame till the jaggery syrup blends well with rice. It should begin to bubble up well. Turn off the stove.
11. Heat a pan with 1/2 cup ghee on a medium flame.
12. Add 1/4 cup of dry coconut pieces and fry them until it turns to golden brown color. Transfer the coconut pieces to a plate.
13. add 15 cashew to ghee and fry them to golden brown color.
14. Now directly add cashew, dry coconut and ghee to pongal. Mix well.
15. If you want you can add enguva to pongal so it gives nice taste.
16. Chakkara pongal is ready.