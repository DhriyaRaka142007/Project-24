# Sweet Pongal | Chakkara Pongali

Sweet Pongal is a Traditional sweet for Hindus. It was Traditionally made with rice, dal, jaggery, ghee and nuts. It was called Chakkara Pongal in Telugu and Sakkarai Pongal in Telugu.



